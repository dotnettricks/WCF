﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

namespace WCFBAL
{
    [DataContract]
    public class Employee
    {
        [DataMember]
        public int EmpID;

        [DataMember]
        public string Name;

        [DataMember]
        public int Salary;

        [DataMember]
        public DateTime JoiningDate;

    }

    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class WCFBALService
    {
        [WebInvoke(Method = "POST")]
        public Employee GetEmpInfo(int mEmpID)
        {
            try
            {
                //suppose you have a list of employee like as in the database

                List<Employee> lst = new List<Employee>() 
                { 
                    new Employee { EmpID = 1, Name = "Deepak", Salary = 12000, JoiningDate = Convert.ToDateTime("11/05/2011") },
                    new Employee { EmpID = 2, Name = "Mohan", Salary = 18000},
                    new Employee { EmpID = 3, Name = "Mohan", JoiningDate = Convert.ToDateTime("06/10/2011") }
                };

                var q = lst.Where(m => m.EmpID == mEmpID).FirstOrDefault();

                Employee mobjEmp = new Employee();
                if (q != null)
                {
                    mobjEmp.EmpID = q.EmpID;
                    mobjEmp.Name = q.Name;
                    mobjEmp.Salary = q.Salary; // comment this line to expect same error 
                    //The no error will be raised since "Salary" field is of int type and default value of int variable is "0", so zero value will be assigned to it. 

                    mobjEmp.JoiningDate = q.JoiningDate; // comment this line and provide mEmpID=1 to raise error 
                    //The error will be raised since "JoiningDate" field is not being serialized because this of DateTime and this has no default value and not assign any value to it
                }

                return mobjEmp;
            }
            catch (Exception mex)
            {
                return null;
            }
        }
    }
}
